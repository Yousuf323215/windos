const settings = {
  ownerName: 'NamaOwnerLu', // Ganti dengan nama owner lu
  botToken: '7890189562:AAH48kK2wfvisCM2yi1vOAPAGplQ36V4IIo', // Ganti dengan token bot Telegram lu
  owner: '6961685110', //OWNER user id
};

module.exports = settings;
